var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[Object.keys(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};

// netlify/functions/next_api_hello/getHandlerFunction.js
var require_getHandlerFunction = __commonJS({
  "netlify/functions/next_api_hello/getHandlerFunction.js"(exports2) {
    var { Buffer: Buffer2 } = require("buffer");
    var http = require("http");
    var queryString = require("querystring");
    var Stream = require("stream");
    var createRequestObject = ({ event, context }) => {
      const {
        requestContext = {},
        path = "",
        multiValueQueryStringParameters,
        pathParameters,
        httpMethod,
        multiValueHeaders = {},
        body,
        isBase64Encoded
      } = event;
      const newStream = new Stream.Readable();
      const req = Object.assign(newStream, http.IncomingMessage.prototype);
      req.url = (requestContext.path || path || "").replace(new RegExp(`^/${requestContext.stage}`), "") || "/";
      let qs = "";
      if (multiValueQueryStringParameters) {
        qs += queryString.stringify(multiValueQueryStringParameters);
      }
      if (pathParameters) {
        const pathParametersQs = queryString.stringify(pathParameters);
        qs += qs.length === 0 ? pathParametersQs : `&${pathParametersQs}`;
      }
      const hasQueryString = qs.length !== 0;
      if (hasQueryString) {
        req.url += `?${qs}`;
      }
      req.method = httpMethod;
      req.rawHeaders = [];
      req.headers = {};
      req.netlifyFunctionParams = { event, context };
      for (const key of Object.keys(multiValueHeaders)) {
        for (const value of multiValueHeaders[key]) {
          req.rawHeaders.push(key);
          req.rawHeaders.push(value);
        }
        req.headers[key.toLowerCase()] = multiValueHeaders[key].toString();
      }
      req.getHeader = (name) => req.headers[name.toLowerCase()];
      req.getHeaders = () => req.headers;
      req.connection = {};
      if (body) {
        req.push(body, isBase64Encoded ? "base64" : void 0);
      }
      req.push(null);
      return req;
    };
    var createResponseObject = ({ onResEnd }) => {
      const response = {
        isBase64Encoded: true,
        multiValueHeaders: {}
      };
      const res = new Stream();
      Object.defineProperty(res, "statusCode", {
        get() {
          return response.statusCode;
        },
        set(statusCode) {
          response.statusCode = statusCode;
        }
      });
      res.headers = {};
      res.writeHead = (status, headers) => {
        response.statusCode = status;
        if (headers)
          res.headers = Object.assign(res.headers, headers);
        return res;
      };
      res.write = (chunk) => {
        if (!response.body) {
          response.body = Buffer2.from("");
        }
        response.body = Buffer2.concat([
          Buffer2.isBuffer(response.body) ? response.body : Buffer2.from(response.body),
          Buffer2.isBuffer(chunk) ? chunk : Buffer2.from(chunk)
        ]);
      };
      res.setHeader = (name, value) => {
        res.headers[name.toLowerCase()] = value;
      };
      res.removeHeader = (name) => {
        delete res.headers[name.toLowerCase()];
      };
      res.getHeader = (name) => res.headers[name.toLowerCase()];
      res.getHeaders = () => res.headers;
      res.hasHeader = (name) => Boolean(res.getHeader(name));
      res.end = (text) => {
        if (text)
          res.write(text);
        if (!res.statusCode) {
          res.statusCode = 200;
        }
        if (response.body) {
          response.body = Buffer2.from(response.body).toString("base64");
        }
        response.multiValueHeaders = res.headers;
        res.writeHead(response.statusCode);
        for (const key of Object.keys(response.multiValueHeaders)) {
          if (!Array.isArray(response.multiValueHeaders[key])) {
            response.multiValueHeaders[key] = [response.multiValueHeaders[key]];
          }
        }
        res.finished = true;
        res.writableEnded = true;
        onResEnd(response);
      };
      return res;
    };
    var renderNextPage = ({ event, context }, nextPage) => {
      const promise = new Promise((resolve) => {
        const req = createRequestObject({ event, context });
        const res = createResponseObject({
          onResEnd: (response) => resolve(response)
        });
        const isNextPage = nextPage.render instanceof Function;
        const isApiRoute = !isNextPage;
        if (isNextPage)
          return nextPage.render(req, res);
        if (isApiRoute)
          return nextPage.default(req, res);
      });
      return promise;
    };
    var getHandlerFunction2 = (nextPage) => async (event, context) => {
      if (!event.multiValueHeaders.hasOwnProperty("x-forwarded-host")) {
        event.multiValueHeaders["x-forwarded-host"] = [event.headers.host];
      }
      const { path } = event;
      console.log("[request]", path);
      const response = await renderNextPage({ event, context }, nextPage);
      Object.keys(response.multiValueHeaders).forEach((key) => {
        response.multiValueHeaders[key] = response.multiValueHeaders[key].map((value) => String(value));
      });
      response.multiValueHeaders["Cache-Control"] = ["no-cache"];
      return response;
    };
    exports2.getHandlerFunction = getHandlerFunction2;
  }
});

// netlify/functions/next_api_hello/nextPage/pages/api/hello.js
var require_hello = __commonJS({
  "netlify/functions/next_api_hello/nextPage/pages/api/hello.js"(exports2, module2) {
    (() => {
      var __webpack_modules__ = {
        948: (__unused_webpack_module, __webpack_exports__2, __webpack_require__2) => {
          "use strict";
          __webpack_require__2.r(__webpack_exports__2);
          __webpack_require__2.d(__webpack_exports__2, {
            "default": () => handler
          });
          function handler(req, res) {
            res.status(200).json({
              name: "John Doe"
            });
          }
        },
        2551: (__unused_webpack_module, __webpack_exports__2, __webpack_require__2) => {
          "use strict";
          __webpack_require__2.r(__webpack_exports__2);
          __webpack_require__2.d(__webpack_exports__2, {
            "default": () => next_serverless_loaderpage_2Fapi_2Fhello_absolutePagePath_private_next_pages_2Fapi_2Fhello_ts_absoluteAppPath_private_next_pages_2F_app_tsx_absoluteDocumentPath_next_2Fdist_2Fpages_2F_document_absoluteErrorPath_next_2Fdist_2Fpages_2F_error_absolute404Path_distDir_private_dot_next_buildId_S45WcXilnL_BhXcLY5yXb_assetPrefix_generateEtags_true_poweredByHeader_true_canonicalBase_basePath_runtimeConfig_previewProps_7B_22previewModeId_22_3A_225dc436fead49dd978742ff1eb9cb6ddf_22_2C_22previewModeSigningKey_22_3A_22c8492b1bec7be54685e3ce79f46d065ecead4db726e40ca40b8f1bfc47100967_22_2C_22previewModeEncryptionKey_22_3A_223fdac5595f865a218b1dc19e1c866ff7546a60f9dcdc19c5e6d0e4ecd70b8e55_22_7D_loadedEnvFiles_W3sicGF0aCI6Ii5lbnYiLCJjb250ZW50cyI6IiMgRW52aXJvbm1lbnQgdmFyaWFibGVzIGRlY2xhcmVkIGluIHRoaXMgZmlsZSBhcmUgYXV0b21hdGljYWxseSBtYWRlIGF2YWlsYWJsZSB0byBQcmlzbWEuXG4jIFNlZSB0aGUgZG9jdW1lbnRhdGlvbiBmb3IgbW9yZSBkZXRhaWw6IGh0dHBzOi8vcHJpcy5seS9kL3ByaXNtYS1zY2hlbWEjdXNpbmctZW52aXJvbm1lbnQtdmFyaWFibGVzXG5cbiMgUHJpc21hIHN1cHBvcnRzIHRoZSBuYXRpdmUgY29ubmVjdGlvbiBzdHJpbmcgZm9ybWF0IGZvciBQb3N0Z3JlU1FMLCBNeVNRTCwgU1FMaXRlLCBTUUwgU2VydmVyIChQcmV2aWV3KSBhbmQgTW9uZ29EQiAoUHJldmlldykuXG4jIFNlZSB0aGUgZG9jdW1lbnRhdGlvbiBmb3IgYWxsIHRoZSBjb25uZWN0aW9uIHN0cmluZyBvcHRpb25zOiBodHRwczovL3ByaXMubHkvZC9jb25uZWN0aW9uLXN0cmluZ3NcblxuREFUQUJBU0VfVVJMID0gbXlzcWw6Ly8zbmtoeTk4Mnhpa3E6cHNjYWxlX3B3X0ZnZlpBZ1ZORmM0N0lPNDB2OFNyOG1BVDRhZXhyMHk5RmxhdGhSdk54dW9AMnIwaG90MGM0NHk2LnVzLWVhc3QtMi5wc2RiLmNsb3VkL2Jsb2ctZGV2P3NzbG1vZGU9cmVxdWlyZSZzc2xhY2NlcHQ9c3RyaWN0JnNzbGNlcnQ9L2V0Yy9zc2wvY2VydC5wZW0ifV0_3D_i18n_
          });
          var node_polyfill_fetch = __webpack_require__2(607);
          ;
          const routes_manifest_namespaceObject = { "Dg": [] };
          var api_handler = __webpack_require__2(8277);
          ;
          const { processEnv } = __webpack_require__2(2333);
          processEnv([{ "path": ".env", "contents": "# Environment variables declared in this file are automatically made available to Prisma.\n# See the documentation for more detail: https://pris.ly/d/prisma-schema#using-environment-variables\n\n# Prisma supports the native connection string format for PostgreSQL, MySQL, SQLite, SQL Server (Preview) and MongoDB (Preview).\n# See the documentation for all the connection string options: https://pris.ly/d/connection-strings\n\nDATABASE_URL = mysql://3nkhy982xikq:pscale_pw_FgfZAgVNFc47IO40v8Sr8mAT4aexr0y9FlathRvNxuo@2r0hot0c44y6.us-east-2.psdb.cloud/blog-dev?sslmode=require&sslaccept=strict&sslcert=/etc/ssl/cert.pem" }]);
          const runtimeConfig = {};
          const combinedRewrites = Array.isArray(routes_manifest_namespaceObject.Dg) ? routes_manifest_namespaceObject.Dg : [];
          if (!Array.isArray(routes_manifest_namespaceObject.Dg)) {
            combinedRewrites.push(...routes_manifest_namespaceObject.Dg.beforeFiles);
            combinedRewrites.push(...routes_manifest_namespaceObject.Dg.afterFiles);
            combinedRewrites.push(...routes_manifest_namespaceObject.Dg.fallback);
          }
          const apiHandler = (0, api_handler.Y)({
            pageModule: __webpack_require__2(948),
            rewrites: combinedRewrites,
            i18n: void 0,
            page: "/api/hello",
            basePath: "",
            pageIsDynamic: false,
            encodedPreviewProps: { previewModeId: "5dc436fead49dd978742ff1eb9cb6ddf", previewModeSigningKey: "c8492b1bec7be54685e3ce79f46d065ecead4db726e40ca40b8f1bfc47100967", previewModeEncryptionKey: "3fdac5595f865a218b1dc19e1c866ff7546a60f9dcdc19c5e6d0e4ecd70b8e55" }
          });
          const next_serverless_loaderpage_2Fapi_2Fhello_absolutePagePath_private_next_pages_2Fapi_2Fhello_ts_absoluteAppPath_private_next_pages_2F_app_tsx_absoluteDocumentPath_next_2Fdist_2Fpages_2F_document_absoluteErrorPath_next_2Fdist_2Fpages_2F_error_absolute404Path_distDir_private_dot_next_buildId_S45WcXilnL_BhXcLY5yXb_assetPrefix_generateEtags_true_poweredByHeader_true_canonicalBase_basePath_runtimeConfig_previewProps_7B_22previewModeId_22_3A_225dc436fead49dd978742ff1eb9cb6ddf_22_2C_22previewModeSigningKey_22_3A_22c8492b1bec7be54685e3ce79f46d065ecead4db726e40ca40b8f1bfc47100967_22_2C_22previewModeEncryptionKey_22_3A_223fdac5595f865a218b1dc19e1c866ff7546a60f9dcdc19c5e6d0e4ecd70b8e55_22_7D_loadedEnvFiles_W3sicGF0aCI6Ii5lbnYiLCJjb250ZW50cyI6IiMgRW52aXJvbm1lbnQgdmFyaWFibGVzIGRlY2xhcmVkIGluIHRoaXMgZmlsZSBhcmUgYXV0b21hdGljYWxseSBtYWRlIGF2YWlsYWJsZSB0byBQcmlzbWEuXG4jIFNlZSB0aGUgZG9jdW1lbnRhdGlvbiBmb3IgbW9yZSBkZXRhaWw6IGh0dHBzOi8vcHJpcy5seS9kL3ByaXNtYS1zY2hlbWEjdXNpbmctZW52aXJvbm1lbnQtdmFyaWFibGVzXG5cbiMgUHJpc21hIHN1cHBvcnRzIHRoZSBuYXRpdmUgY29ubmVjdGlvbiBzdHJpbmcgZm9ybWF0IGZvciBQb3N0Z3JlU1FMLCBNeVNRTCwgU1FMaXRlLCBTUUwgU2VydmVyIChQcmV2aWV3KSBhbmQgTW9uZ29EQiAoUHJldmlldykuXG4jIFNlZSB0aGUgZG9jdW1lbnRhdGlvbiBmb3IgYWxsIHRoZSBjb25uZWN0aW9uIHN0cmluZyBvcHRpb25zOiBodHRwczovL3ByaXMubHkvZC9jb25uZWN0aW9uLXN0cmluZ3NcblxuREFUQUJBU0VfVVJMID0gbXlzcWw6Ly8zbmtoeTk4Mnhpa3E6cHNjYWxlX3B3X0ZnZlpBZ1ZORmM0N0lPNDB2OFNyOG1BVDRhZXhyMHk5RmxhdGhSdk54dW9AMnIwaG90MGM0NHk2LnVzLWVhc3QtMi5wc2RiLmNsb3VkL2Jsb2ctZGV2P3NzbG1vZGU9cmVxdWlyZSZzc2xhY2NlcHQ9c3RyaWN0JnNzbGNlcnQ9L2V0Yy9zc2wvY2VydC5wZW0ifV0_3D_i18n_ = apiHandler;
        },
        9521: (module3) => {
          function webpackEmptyContext(req) {
            var e = new Error("Cannot find module '" + req + "'");
            e.code = "MODULE_NOT_FOUND";
            throw e;
          }
          webpackEmptyContext.keys = () => [];
          webpackEmptyContext.resolve = webpackEmptyContext;
          webpackEmptyContext.id = 9521;
          module3.exports = webpackEmptyContext;
        },
        4293: (module3) => {
          "use strict";
          module3.exports = require("buffer");
        },
        6417: (module3) => {
          "use strict";
          module3.exports = require("crypto");
        },
        8614: (module3) => {
          "use strict";
          module3.exports = require("events");
        },
        5747: (module3) => {
          "use strict";
          module3.exports = require("fs");
        },
        8605: (module3) => {
          "use strict";
          module3.exports = require("http");
        },
        7211: (module3) => {
          "use strict";
          module3.exports = require("https");
        },
        5622: (module3) => {
          "use strict";
          module3.exports = require("path");
        },
        1191: (module3) => {
          "use strict";
          module3.exports = require("querystring");
        },
        2413: (module3) => {
          "use strict";
          module3.exports = require("stream");
        },
        4304: (module3) => {
          "use strict";
          module3.exports = require("string_decoder");
        },
        8835: (module3) => {
          "use strict";
          module3.exports = require("url");
        },
        1669: (module3) => {
          "use strict";
          module3.exports = require("util");
        },
        8761: (module3) => {
          "use strict";
          module3.exports = require("zlib");
        }
      };
      var __webpack_module_cache__ = {};
      function __webpack_require__(moduleId) {
        var cachedModule = __webpack_module_cache__[moduleId];
        if (cachedModule !== void 0) {
          return cachedModule.exports;
        }
        var module3 = __webpack_module_cache__[moduleId] = {
          exports: {}
        };
        var threw = true;
        try {
          __webpack_modules__[moduleId](module3, module3.exports, __webpack_require__);
          threw = false;
        } finally {
          if (threw)
            delete __webpack_module_cache__[moduleId];
        }
        return module3.exports;
      }
      __webpack_require__.m = __webpack_modules__;
      __webpack_require__.x = () => {
        var __webpack_exports__2 = __webpack_require__.O(void 0, [15, 639, 277], () => __webpack_require__(2551));
        __webpack_exports__2 = __webpack_require__.O(__webpack_exports__2);
        return __webpack_exports__2;
      };
      (() => {
        var deferred = [];
        __webpack_require__.O = (result, chunkIds, fn, priority) => {
          if (chunkIds) {
            priority = priority || 0;
            for (var i = deferred.length; i > 0 && deferred[i - 1][2] > priority; i--)
              deferred[i] = deferred[i - 1];
            deferred[i] = [chunkIds, fn, priority];
            return;
          }
          var notFulfilled = Infinity;
          for (var i = 0; i < deferred.length; i++) {
            var [chunkIds, fn, priority] = deferred[i];
            var fulfilled = true;
            for (var j = 0; j < chunkIds.length; j++) {
              if ((priority & false || notFulfilled >= priority) && Object.keys(__webpack_require__.O).every((key) => __webpack_require__.O[key](chunkIds[j]))) {
                chunkIds.splice(j--, 1);
              } else {
                fulfilled = false;
                if (priority < notFulfilled)
                  notFulfilled = priority;
              }
            }
            if (fulfilled) {
              deferred.splice(i--, 1);
              var r = fn();
              if (r !== void 0)
                result = r;
            }
          }
          return result;
        };
      })();
      (() => {
        __webpack_require__.d = (exports3, definition) => {
          for (var key in definition) {
            if (__webpack_require__.o(definition, key) && !__webpack_require__.o(exports3, key)) {
              Object.defineProperty(exports3, key, { enumerable: true, get: definition[key] });
            }
          }
        };
      })();
      (() => {
        __webpack_require__.f = {};
        __webpack_require__.e = (chunkId) => {
          return Promise.all(Object.keys(__webpack_require__.f).reduce((promises, key) => {
            __webpack_require__.f[key](chunkId, promises);
            return promises;
          }, []));
        };
      })();
      (() => {
        __webpack_require__.u = (chunkId) => {
          return "" + chunkId + ".js";
        };
      })();
      (() => {
        __webpack_require__.o = (obj, prop) => Object.prototype.hasOwnProperty.call(obj, prop);
      })();
      (() => {
        __webpack_require__.r = (exports3) => {
          if (typeof Symbol !== "undefined" && Symbol.toStringTag) {
            Object.defineProperty(exports3, Symbol.toStringTag, { value: "Module" });
          }
          Object.defineProperty(exports3, "__esModule", { value: true });
        };
      })();
      __webpack_require__.__NEXT_FONT_MANIFEST__ = [];
      process.env.__NEXT_OPTIMIZE_FONTS = JSON.stringify(true);
      (() => {
        var installedChunks = {
          453: 1
        };
        __webpack_require__.O.require = (chunkId) => installedChunks[chunkId];
        var installChunk = (chunk) => {
          var moreModules = chunk.modules, chunkIds = chunk.ids, runtime = chunk.runtime;
          for (var moduleId in moreModules) {
            if (__webpack_require__.o(moreModules, moduleId)) {
              __webpack_require__.m[moduleId] = moreModules[moduleId];
            }
          }
          if (runtime)
            runtime(__webpack_require__);
          for (var i = 0; i < chunkIds.length; i++)
            installedChunks[chunkIds[i]] = 1;
          __webpack_require__.O();
        };
        __webpack_require__.f.require = (chunkId, promises) => {
          if (!installedChunks[chunkId]) {
            if (true) {
              installChunk(require("./hello-CWC6BBZ2-0.js")("../../chunks/" + __webpack_require__.u(chunkId)));
            } else
              installedChunks[chunkId] = 1;
          }
        };
      })();
      (() => {
        var next = __webpack_require__.x;
        __webpack_require__.x = () => {
          __webpack_require__.e(15);
          __webpack_require__.e(639);
          __webpack_require__.e(277);
          return next();
        };
      })();
      var __webpack_exports__ = __webpack_require__.x();
      module2.exports = __webpack_exports__;
    })();
  }
});

// netlify/functions/next_api_hello/next_api_hello.js
var { getHandlerFunction } = require_getHandlerFunction();
exports.handler = getHandlerFunction(require_hello());
